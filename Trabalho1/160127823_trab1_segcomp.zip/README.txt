Primeiramente o código foi feita usando CLion da JetBrains no Windows. Foi rodado com o compilador MinGW-w64 e foi feita em C++20 . É tudo feito no próprio terminal , logo para escrever o texto precisa de CLTR-C CLTR-V porém texto com pula linha(ou enter) no meio dele pode não funcionar.\\\\
Para rodar pode usar:

g++ cifrador.cpp
g++ decifrador.cpp
g++ quebra.cpp

Por exemplo:
g++ quebra.cpp

No terminal vai aparecer:
Qual a criptografia?

Se escrever:
rvgllakieg tye tirtucatzoe.  whvnvvei i winu mpsecf xronieg giid abfuk thv mfuty; wyenvvvr ik ij a drmg, drzzqly eomemsei in dy jouc; wyenvvvr i wied mpsvlf znmollnkarzlp palszng seworv cfffzn narvhfusvs, rnd srzngznx up khv rerr ff emeiy flnvrac i deek; aed ejpvcirlcy wyeeevvr dy hppfs gvt jucy ae upgei haed ff mv, tyat zt ieqliies r skroeg dorrl grieczplv tf prvvvnt de wrod dvliseiatvlp stvpginx ieto khv stievt, aed detyouicrlcy keotkieg geoglv's hrtj ofw--tyen, z atcolnk it yixh tzmv to xek to jer as jofn aj i tan.  khzs ij mp susskitltv foi pzstfl rnd sacl.  wzty a pyicosfpyicrl wlolrzsh tako tyrfws yidsecf lpoe hzs snoid; i huzetcy kakv tf thv syip.  khvre zs eotyieg slrgrijieg ie tyis.  zf khep blt keen it, rldosk acl mvn zn tyezr dvgiee, jode tzmv or ftyer, thvrijh merp nvarcy khe jade fvecinxs kowrrus tye fcern nity mv.

Obtém:

Tamanho da key = 5

Senha(ENG): ARARA

Senha(Portugues): BQAQZ

Process finished with exit code 0